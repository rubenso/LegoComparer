﻿namespace LegoComparer.Model.Result
{
    public class LegoResponseError
    {
    }
}